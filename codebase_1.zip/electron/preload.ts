// Forward-compat preload – imports the real, type-safe bridge
export * from '../src/preload/preload';

