// Mock the entire electron module
jest.mock('electron', () => {
  const mockBrowserWindowInstance = jest.fn().mockImplementation((options) => ({
    webContents: {
      getLastWebPreferences: jest.fn().mockReturnValue(options.webPreferences || {}),
    },
    isDestroyed: jest.fn().mockReturnValue(false),
    close: jest.fn(),
    // Add any other methods or properties your code under test might use on an instance
  }));

  return {
    __esModule: true, // Important for ESM compatibility with jest.mock
    app: {
      isReady: jest.fn().mockReturnValue(true),
      whenReady: jest.fn().mockResolvedValue(undefined),
      getAppPath: jest.fn().mockReturnValue('/mock/app/path'),
    },
    BrowserWindow: mockBrowserWindowInstance,
  };
});

import { BrowserWindow } from 'electron'; // app is mocked in the jest.mock block above
import { createWindow } from '../../src/main/windowFactory';

// Get a typed reference to the mocked BrowserWindow
const mockedBrowserWindow = jest.mocked(BrowserWindow);

describe('windowFactory security defaults', () => {
  beforeEach(() => {
    // Clear all instances and calls to constructor and all methods:
    mockedBrowserWindow.mockClear();
    // Example for app, if its methods were mocked and need clearing:
    // mockedApp.isReady.mockClear(); 
  });

  it('creates a window with secure defaults', () => {
    createWindow(); // Call the function that creates the window
    
    // Use the typed mock for assertions
    expect(mockedBrowserWindow).toHaveBeenCalledWith(
      expect.objectContaining({
        webPreferences: expect.objectContaining({
          contextIsolation: true,
          sandbox: true,
          nodeIntegration: false,
          webSecurity: true,
          enableRemoteModule: false,
        }),
      })
    );
  });
});
